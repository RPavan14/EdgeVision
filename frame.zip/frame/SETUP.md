# Setup Guide - Edge Detection Viewer

This guide will help you set up and build the Real-Time Edge Detection Viewer project.

## Prerequisites

### 1. Android Development Environment
- **Android Studio** (latest stable version)
  - Download from: https://developer.android.com/studio
- **Android SDK** (API 24+)
  - Install via Android Studio SDK Manager
- **Android NDK** (r21+)
  - Install via Android Studio SDK Manager (SDK Tools tab)
  - Verify installation: `File → Settings → Appearance & Behavior → System Settings → Android SDK → SDK Tools`

### 2. OpenCV Android SDK
1. Download OpenCV Android SDK from: https://opencv.org/releases/
2. Extract the archive to a location (e.g., `C:\OpenCV-android-sdk` on Windows)
3. Note the path - you'll need it for configuration

### 3. Node.js (for Web Viewer)
- Download from: https://nodejs.org/
- Version 14+ required
- Verify: `node --version` and `npm --version`

## Project Setup

### Step 1: Clone/Extract Project
```bash
# If using git
git clone <repository-url>
cd frame

# Or extract the project folder
```

### Step 2: Configure Android Project

1. **Create `local.properties`** (copy from template):
   ```bash
   # On Windows
   copy local.properties.template local.properties
   
   # On Linux/Mac
   cp local.properties.template local.properties
   ```

2. **Edit `local.properties`** with your paths:
   ```properties
   sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk
   ndk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk\\ndk\\<version>
   opencv.dir=C\:\\OpenCV-android-sdk
   ```
   
   **Important**: 
   - Replace `YourName` with your Windows username
   - Replace `<version>` with your NDK version (e.g., `25.2.9519653`)
   - Set `opencv.dir` to the directory containing the OpenCV SDK (not the `jni` subdirectory)

3. **Alternative: Set Environment Variable**
   - Set `OPENCV_DIR` environment variable to your OpenCV SDK path
   - CMake will try to find it automatically

### Step 3: Open in Android Studio

1. Open Android Studio
2. Select `File → Open` and navigate to the project root (`frame` folder)
3. Wait for Gradle sync to complete
4. If OpenCV is not found, check the error message and verify paths

### Step 4: Build Native Libraries

The native C++ code will be built automatically when you build the app. However, you can verify the setup:

```bash
# From project root
cd app
./gradlew assembleDebug
```

**Troubleshooting OpenCV Issues:**
- If CMake can't find OpenCV, check that `opencv.dir` in `local.properties` points to the correct directory
- The expected structure is: `<opencv-dir>/sdk/native/jni/OpenCVConfig.cmake`
- You can also set `OPENCV_DIR` environment variable

### Step 5: Build and Run Android App

1. **Connect Device or Start Emulator**
   - Physical device: Enable USB debugging
   - Emulator: Create AVD with API 24+ (Android 7.0+)

2. **Build and Install**
   ```bash
   ./gradlew installDebug
   ```
   
   Or use Android Studio:
   - Click `Run` button (green play icon)
   - Select your device/emulator
   - Grant camera permission when prompted

3. **Verify**
   - App should open and request camera permission
   - After granting, you should see the camera feed with edge detection
   - Toggle button switches between edge detection and grayscale
   - FPS counter shows in top-left

### Step 6: Build Web Viewer

1. **Navigate to web directory**
   ```bash
   cd web
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Build TypeScript**
   ```bash
   npm run build
   ```

4. **Serve locally**
   ```bash
   npm run serve
   # Opens at http://localhost:8080
   ```

5. **Open in browser**
   - Navigate to `http://localhost:8080`
   - You should see the web viewer with sample frame

## Project Structure

```
frame/
├── app/                          # Android application
│   ├── src/main/
│   │   ├── java/.../            # Kotlin source files
│   │   ├── cpp/                 # CMakeLists.txt
│   │   ├── jni/                 # OpenCV edge detection
│   │   ├── gl/                  # OpenGL ES 2.0 renderer
│   │   ├── res/                 # Resources
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── web/                          # TypeScript web viewer
│   ├── src/viewer.ts
│   ├── dist/index.html
│   └── package.json
├── build.gradle                  # Root build file
├── settings.gradle
└── README.md
```

## Common Issues

### Issue: OpenCV not found
**Solution:**
- Verify `opencv.dir` in `local.properties` is correct
- Check that OpenCV SDK is extracted completely
- Try setting `OPENCV_DIR` environment variable

### Issue: NDK not found
**Solution:**
- Install NDK via Android Studio SDK Manager
- Verify `ndk.dir` in `local.properties`
- Check NDK version matches `build.gradle`

### Issue: Camera permission denied
**Solution:**
- Grant camera permission in app settings
- Check `AndroidManifest.xml` has camera permission

### Issue: Build fails with CMake errors
**Solution:**
- Ensure CMake is installed (via Android Studio SDK Manager)
- Check CMake version in `CMakeLists.txt` matches installed version
- Clean and rebuild: `./gradlew clean build`

### Issue: App crashes on startup
**Solution:**
- Check logcat for errors: `adb logcat | grep -i error`
- Verify native libraries are built: Check `app/build/intermediates/`
- Ensure device/emulator supports Camera2 API

## Performance Optimization

To achieve 10-15 FPS target:

1. **Reduce resolution**: Edit `openCamera()` in `MainActivity.kt`
   ```kotlin
   val previewSize = streamConfigurationMap?.getOutputSizes(ImageFormat.YUV_420_888)
       ?.firstOrNull { it.width <= 640 && it.height <= 480 }  // Lower resolution
   ```

2. **Adjust Canny parameters**: Edit `edge_detector.cpp`
   ```cpp
   lowThreshold = 30.0;   // Lower = more edges
   highThreshold = 100.0; // Adjust for performance
   ```

3. **Skip frames**: Process every Nth frame instead of all frames

## Next Steps

- Integrate web viewer with Android app (HTTP/WebSocket)
- Add more edge detection algorithms
- Implement frame saving functionality
- Add configuration UI for edge detection parameters

## Support

For issues or questions:
1. Check the README.md
2. Review logcat output: `adb logcat`
3. Verify all prerequisites are installed correctly

