#include <jni.h>
#include <string>
#include <android/log.h>
#include "edge_detector.h"
#include "gl_renderer.h"

#define LOG_TAG "NativeLib"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static EdgeDetector* g_edgeDetector = nullptr;
static GLRenderer* g_glRenderer = nullptr;

extern "C" JNIEXPORT jlong JNICALL
Java_com_example_edgedetection_NativeProcessor_nativeInit(JNIEnv *env, jobject /* this */) {
    LOGI("Initializing edge detector");
    
    if (g_edgeDetector == nullptr) {
        g_edgeDetector = new EdgeDetector();
        if (!g_edgeDetector->initialize()) {
            LOGE("Failed to initialize edge detector");
            delete g_edgeDetector;
            g_edgeDetector = nullptr;
            return 0;
        }
    }
    
    return reinterpret_cast<jlong>(g_edgeDetector);
}

extern "C" JNIEXPORT jint JNICALL
Java_com_example_edgedetection_NativeProcessor_nativeProcessFrame(
    JNIEnv *env,
    jobject /* this */,
    jbyteArray inputBuffer,
    jint width,
    jint height,
    jbyteArray outputBuffer,
    jboolean edgeMode
) {
    if (g_edgeDetector == nullptr) {
        LOGE("Edge detector not initialized");
        return -1;
    }
    
    // Get input buffer
    jbyte* inputBytes = env->GetByteArrayElements(inputBuffer, nullptr);
    if (inputBytes == nullptr) {
        LOGE("Failed to get input buffer");
        return -1;
    }
    
    // Get output buffer
    jbyte* outputBytes = env->GetByteArrayElements(outputBuffer, nullptr);
    if (outputBytes == nullptr) {
        LOGE("Failed to get output buffer");
        env->ReleaseByteArrayElements(inputBuffer, inputBytes, JNI_ABORT);
        return -1;
    }
    
    // Process frame
    bool success = g_edgeDetector->processFrame(
        reinterpret_cast<unsigned char*>(inputBytes),
        width,
        height,
        reinterpret_cast<unsigned char*>(outputBytes),
        edgeMode == JNI_TRUE
    );
    
    // Release buffers
    env->ReleaseByteArrayElements(inputBuffer, inputBytes, JNI_ABORT);
    env->ReleaseByteArrayElements(outputBuffer, outputBytes, 0);
    
    return success ? 0 : -1;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_edgedetection_NativeProcessor_nativeRelease(JNIEnv *env, jobject /* this */, jlong handle) {
    if (g_edgeDetector != nullptr) {
        delete g_edgeDetector;
        g_edgeDetector = nullptr;
        LOGI("Edge detector released");
    }
}

// YUV to RGBA conversion helper
extern "C" JNIEXPORT jint JNICALL
Java_com_example_edgedetection_NativeProcessor_convertYUVtoRGBA(
    JNIEnv *env,
    jobject /* this */,
    jbyteArray yuvBuffer,
    jint width,
    jint height,
    jbyteArray rgbaBuffer
) {
    jbyte* yuvBytes = env->GetByteArrayElements(yuvBuffer, nullptr);
    jbyte* rgbaBytes = env->GetByteArrayElements(rgbaBuffer, nullptr);
    
    if (yuvBytes == nullptr || rgbaBytes == nullptr) {
        if (yuvBytes) env->ReleaseByteArrayElements(yuvBuffer, yuvBytes, JNI_ABORT);
        if (rgbaBytes) env->ReleaseByteArrayElements(rgbaBuffer, rgbaBytes, JNI_ABORT);
        return -1;
    }
    
    // Use OpenCV to convert YUV to RGBA
    cv::Mat yuvMat(height + height/2, width, CV_8UC1, yuvBytes);
    cv::Mat rgbaMat(height, width, CV_8UC4, rgbaBytes);
    cv::cvtColor(yuvMat, rgbaMat, cv::COLOR_YUV2RGBA_NV21);
    
    env->ReleaseByteArrayElements(yuvBuffer, yuvBytes, JNI_ABORT);
    env->ReleaseByteArrayElements(rgbaBuffer, rgbaBytes, 0);
    
    return 0;
}

