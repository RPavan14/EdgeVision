#include "edge_detector.h"
#include <android/log.h>

#define LOG_TAG "EdgeDetector"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

EdgeDetector::EdgeDetector()
    : initialized(false)
    , lowThreshold(50.0)
    , highThreshold(150.0)
    , apertureSize(3)
{
}

EdgeDetector::~EdgeDetector() {
    release();
}

bool EdgeDetector::initialize() {
    if (initialized) {
        return true;
    }
    
    try {
        // Initialize OpenCV matrices
        // They will be allocated when processing frames
        initialized = true;
        LOGI("Edge detector initialized");
        return true;
    } catch (const cv::Exception& e) {
        LOGE("OpenCV exception during initialization: %s", e.what());
        return false;
    }
}

bool EdgeDetector::processFrame(
    unsigned char* inputFrame,
    int width,
    int height,
    unsigned char* outputFrame,
    bool edgeMode
) {
    if (!initialized) {
        LOGE("Edge detector not initialized");
        return false;
    }
    
    try {
        // Input frame is RGBA format
        // Create OpenCV Mat from input (RGBA -> BGR for OpenCV)
        cv::Mat rgbaMat(height, width, CV_8UC4, inputFrame);
        cv::Mat bgrMat;
        cv::cvtColor(rgbaMat, bgrMat, cv::COLOR_RGBA2BGR);
        
        if (edgeMode) {
            // Convert to grayscale
            cv::cvtColor(bgrMat, grayMat, cv::COLOR_BGR2GRAY);
            
            // Apply Canny edge detection
            cv::Canny(
                grayMat,
                edgeMat,
                lowThreshold,
                highThreshold,
                apertureSize
            );
            
            // Convert edge image back to BGR (for visualization)
            cv::cvtColor(edgeMat, outputMat, cv::COLOR_GRAY2BGR);
        } else {
            // Just convert to grayscale
            cv::cvtColor(bgrMat, grayMat, cv::COLOR_BGR2GRAY);
            cv::cvtColor(grayMat, outputMat, cv::COLOR_GRAY2BGR);
        }
        
        // Convert BGR back to RGBA for output
        cv::Mat rgbaOutput;
        cv::cvtColor(outputMat, rgbaOutput, cv::COLOR_BGR2RGBA);
        
        // Copy to output buffer
        memcpy(outputFrame, rgbaOutput.data, width * height * 4);
        
        return true;
    } catch (const cv::Exception& e) {
        LOGE("OpenCV exception during processing: %s", e.what());
        return false;
    } catch (...) {
        LOGE("Unknown exception during processing");
        return false;
    }
}

void EdgeDetector::release() {
    if (initialized) {
        inputMat.release();
        grayMat.release();
        edgeMat.release();
        outputMat.release();
        initialized = false;
        LOGI("Edge detector released");
    }
}

