#ifndef EDGE_DETECTOR_H
#define EDGE_DETECTOR_H

#include <opencv2/opencv.hpp>
#include <opencv2/imgproc.hpp>

class EdgeDetector {
public:
    EdgeDetector();
    ~EdgeDetector();
    
    bool initialize();
    bool processFrame(
        unsigned char* inputFrame,
        int width,
        int height,
        unsigned char* outputFrame,
        bool edgeMode
    );
    void release();

private:
    cv::Mat inputMat;
    cv::Mat grayMat;
    cv::Mat edgeMat;
    cv::Mat outputMat;
    bool initialized;
    
    // Canny edge detection parameters
    double lowThreshold;
    double highThreshold;
    int apertureSize;
};

#endif // EDGE_DETECTOR_H

