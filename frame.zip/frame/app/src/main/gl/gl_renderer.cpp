#include "gl_renderer.h"
#include <android/log.h>
#include <string>

#define LOG_TAG "GLRenderer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static const char* vertexShaderSource = R"(
attribute vec4 aPosition;
attribute vec2 aTexCoord;
varying vec2 vTexCoord;
void main() {
    gl_Position = aPosition;
    vTexCoord = aTexCoord;
}
)";

static const char* fragmentShaderSource = R"(
precision mediump float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
void main() {
    gl_FragColor = texture2D(uTexture, vTexCoord);
}
)";

GLRenderer::GLRenderer()
    : programHandle(0)
    , textureHandle(0)
    , positionHandle(0)
    , texCoordHandle(0)
    , textureUniformHandle(0)
    , initialized(false)
{
}

GLRenderer::~GLRenderer() {
    release();
}

bool GLRenderer::initialize() {
    if (initialized) {
        return true;
    }
    
    // Create shader program
    if (!createShaderProgram()) {
        LOGE("Failed to create shader program");
        return false;
    }
    
    // Get attribute/uniform locations
    positionHandle = glGetAttribLocation(programHandle, "aPosition");
    texCoordHandle = glGetAttribLocation(programHandle, "aTexCoord");
    textureUniformHandle = glGetUniformLocation(programHandle, "uTexture");
    
    // Generate texture
    glGenTextures(1, &textureHandle);
    glBindTexture(GL_TEXTURE_2D, textureHandle);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    initialized = true;
    LOGI("GL renderer initialized");
    return true;
}

bool GLRenderer::createShaderProgram() {
    GLuint vertexShader = loadShader(GL_VERTEX_SHADER, vertexShaderSource);
    if (vertexShader == 0) {
        return false;
    }
    
    GLuint fragmentShader = loadShader(GL_FRAGMENT_SHADER, fragmentShaderSource);
    if (fragmentShader == 0) {
        glDeleteShader(vertexShader);
        return false;
    }
    
    programHandle = glCreateProgram();
    if (programHandle == 0) {
        LOGE("Failed to create program");
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
        return false;
    }
    
    glAttachShader(programHandle, vertexShader);
    glAttachShader(programHandle, fragmentShader);
    glLinkProgram(programHandle);
    
    GLint linkStatus;
    glGetProgramiv(programHandle, GL_LINK_STATUS, &linkStatus);
    if (linkStatus == 0) {
        GLint infoLen = 0;
        glGetProgramiv(programHandle, GL_INFO_LOG_LENGTH, &infoLen);
        if (infoLen > 1) {
            char* infoLog = new char[infoLen];
            glGetProgramInfoLog(programHandle, infoLen, nullptr, infoLog);
            LOGE("Program link error: %s", infoLog);
            delete[] infoLog;
        }
        glDeleteProgram(programHandle);
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);
        return false;
    }
    
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
    
    return true;
}

GLuint GLRenderer::loadShader(GLenum type, const char* source) {
    GLuint shader = glCreateShader(type);
    if (shader == 0) {
        LOGE("Failed to create shader");
        return 0;
    }
    
    glShaderSource(shader, 1, &source, nullptr);
    glCompileShader(shader);
    
    GLint compiled;
    glGetShaderiv(shader, GL_COMPILED, &compiled);
    if (compiled == 0) {
        GLint infoLen = 0;
        glGetProgramiv(shader, GL_INFO_LOG_LENGTH, &infoLen);
        if (infoLen > 1) {
            char* infoLog = new char[infoLen];
            glGetShaderInfoLog(shader, infoLen, nullptr, infoLog);
            LOGE("Shader compilation error: %s", infoLog);
            delete[] infoLog;
        }
        glDeleteShader(shader);
        return 0;
    }
    
    return shader;
}

void GLRenderer::render() {
    if (!initialized) {
        return;
    }
    
    glUseProgram(programHandle);
    
    // Set vertex attributes (assuming they're set up externally)
    // This is a simplified version - actual rendering setup is done in Java
    
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, textureHandle);
    glUniform1i(textureUniformHandle, 0);
}

void GLRenderer::release() {
    if (initialized) {
        if (textureHandle != 0) {
            glDeleteTextures(1, &textureHandle);
            textureHandle = 0;
        }
        if (programHandle != 0) {
            glDeleteProgram(programHandle);
            programHandle = 0;
        }
        initialized = false;
        LOGI("GL renderer released");
    }
}

