#ifndef GL_RENDERER_H
#define GL_RENDERER_H

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include <EGL/egl.h>

class GLRenderer {
public:
    GLRenderer();
    ~GLRenderer();
    
    bool initialize();
    void render();
    void release();

private:
    GLuint programHandle;
    GLuint textureHandle;
    GLuint positionHandle;
    GLuint texCoordHandle;
    GLuint textureUniformHandle;
    
    bool initialized;
    
    bool createShaderProgram();
    GLuint loadShader(GLenum type, const char* source);
};

#endif // GL_RENDERER_H

