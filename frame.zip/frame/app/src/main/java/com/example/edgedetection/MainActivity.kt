package com.example.edgedetection

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.Image
import android.media.ImageReader
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Size
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var glSurfaceView: GLSurfaceView
    private lateinit var fpsTextView: TextView
    private lateinit var toggleButton: FloatingActionButton
    
    private var cameraDevice: CameraDevice? = null
    private var cameraCaptureSession: CameraCaptureSession? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null
    
    private var nativeProcessor: NativeProcessor? = null
    private var glRenderer: EdgeGLRenderer? = null
    private var frameServer: FrameServer? = null
    
    private var isEdgeMode = true
    private var frameCount = 0
    private var lastFpsTime = System.currentTimeMillis()
    private var frameWidth = 640
    private var frameHeight = 480
    private var sendToServer = true // Automatically send frames to web server
    
    private val cameraStateCallback = object : CameraDevice.StateCallback() {
        override fun onOpened(camera: CameraDevice) {
            cameraDevice = camera
            startPreview()
        }
        
        override fun onDisconnected(camera: CameraDevice) {
            camera.close()
            cameraDevice = null
        }
        
        override fun onError(camera: CameraDevice, error: Int) {
            camera.close()
            cameraDevice = null
            Log.e(TAG, "Camera error: $error")
        }
    }
    
    private val imageAvailableListener = ImageReader.OnImageAvailableListener { reader ->
        val image = reader.acquireLatestImage()
        image?.let {
            processImage(it)
            it.close()
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        glSurfaceView = findViewById(R.id.glSurfaceView)
        fpsTextView = findViewById(R.id.fpsTextView)
        toggleButton = findViewById(R.id.toggleButton)
        
        // Initialize native processor
        nativeProcessor = NativeProcessor()
        nativeProcessor?.initialize()
        
        // Initialize OpenGL renderer
        glRenderer = EdgeGLRenderer(this)
        glSurfaceView.setEGLContextClientVersion(2)
        glSurfaceView.setRenderer(glRenderer)
        glSurfaceView.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
        
        // Initialize frame server - automatically sends frames to web viewer
        // Note: Use 10.0.2.2 for Android emulator, or your computer's IP for physical device
        // For emulator (default):
        frameServer = FrameServer("http://10.0.2.2:8080")
        
        // For physical device, uncomment and set your computer's IP:
        // frameServer = FrameServer("http://192.168.1.XXX:8080") // Replace XXX with your PC's IP
        
        toggleButton.setOnClickListener {
            isEdgeMode = !isEdgeMode
            nativeProcessor?.setEdgeMode(isEdgeMode)
        }
        
        // Request camera permission
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                REQUEST_CAMERA_PERMISSION
            )
        } else {
            setupCamera()
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupCamera()
            }
        }
    }
    
    private fun setupCamera() {
        // Automatically open camera when permission is granted
        openCamera(frameWidth, frameHeight)
    }
    
    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraBackground").also { it.start() }
        backgroundHandler = Handler(backgroundThread?.looper!!)
    }
    
    private fun stopBackgroundThread() {
        backgroundThread?.quitSafely()
        try {
            backgroundThread?.join()
            backgroundThread = null
            backgroundHandler = null
        } catch (e: InterruptedException) {
            e.printStackTrace()
        }
    }
    
    private fun openCamera(width: Int, height: Int) {
        val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        try {
            val cameraId = cameraManager.cameraIdList[0]
            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            val streamConfigurationMap = characteristics.get(
                CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP
            )
            
            val previewSize = streamConfigurationMap?.getOutputSizes(ImageFormat.YUV_420_888)
                ?.firstOrNull { it.width <= 1280 && it.height <= 720 } 
                ?: streamConfigurationMap?.getOutputSizes(ImageFormat.YUV_420_888)?.get(0)
                ?: Size(640, 480)
            
            frameWidth = previewSize.width
            frameHeight = previewSize.height
            
            // Create ImageReader
            imageReader = ImageReader.newInstance(
                frameWidth, frameHeight, ImageFormat.YUV_420_888, 2
            )
            imageReader?.setOnImageAvailableListener(imageAvailableListener, backgroundHandler)
            
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            
            startBackgroundThread()
            cameraManager.openCamera(cameraId, cameraStateCallback, backgroundHandler)
        } catch (e: Exception) {
            Log.e(TAG, "Error opening camera", e)
        }
    }
    
    private fun startPreview() {
        val surface = imageReader?.surface ?: return
        
        try {
            val captureRequestBuilder = cameraDevice?.createCaptureRequest(
                CameraDevice.TEMPLATE_PREVIEW
            )
            captureRequestBuilder?.addTarget(surface)
            
            cameraDevice?.createCaptureSession(
                listOf(surface),
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(session: CameraCaptureSession) {
                        cameraCaptureSession = session
                        captureRequestBuilder?.let { request ->
                            request.set(
                                CaptureRequest.CONTROL_AF_MODE,
                                CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
                            )
                            session.setRepeatingRequest(request.build(), null, backgroundHandler)
                        }
                    }
                    
                    override fun onConfigureFailed(session: CameraCaptureSession) {
                        Log.e(TAG, "Camera capture session configuration failed")
                    }
                },
                backgroundHandler
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error starting preview", e)
        }
    }
    
    private fun processImage(image: Image) {
        frameCount++
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastFpsTime >= 1000) {
            val fps = frameCount
            frameCount = 0
            lastFpsTime = currentTime
            runOnUiThread {
                fpsTextView.text = getString(R.string.fps_label, fps)
            }
        }
        
        // Convert YUV to RGBA using native code
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        
        // NV21 format: Y plane + interleaved VU plane
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        
        // Convert YUV to RGBA in native code
        val rgbaBytes = ByteArray(frameWidth * frameHeight * 4)
        nativeProcessor?.convertYUVtoRGBA(nv21, frameWidth, frameHeight, rgbaBytes)
        
        // Process frame in native code
        backgroundHandler?.post {
            val processedFrame = nativeProcessor?.processFrame(rgbaBytes, frameWidth, frameHeight)
            
            // Update OpenGL texture
            processedFrame?.let {
                glRenderer?.updateTexture(it, frameWidth, frameHeight)
                runOnUiThread {
                    glSurfaceView.requestRender()
                }
                
                // Automatically send processed frame to web server
                if (sendToServer && frameServer != null) {
                    // Send frame asynchronously to avoid blocking rendering
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            frameServer?.sendFrameOnce(it, frameWidth, frameHeight)
                        } catch (e: Exception) {
                            // Silently handle network errors - don't spam logcat
                            if (System.currentTimeMillis() % 5000 < 100) { // Log once every 5 seconds
                                Log.d(TAG, "Frame server unavailable (this is normal if web server isn't running)")
                            }
                        }
                    }
                }
            }
        }
    }
    
    
    private fun closeCamera() {
        cameraCaptureSession?.close()
        cameraCaptureSession = null
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        stopBackgroundThread()
    }
    
    override fun onResume() {
        super.onResume()
        glSurfaceView.onResume()
        // Automatically resume camera if permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED) {
            if (cameraDevice == null) {
                setupCamera()
            }
        }
    }
    
    override fun onPause() {
        super.onPause()
        glSurfaceView.onPause()
        closeCamera()
    }
    
    override fun onDestroy() {
        super.onDestroy()
        nativeProcessor?.release()
        glRenderer?.release()
        frameServer?.stopSendingFrames()
    }
    
    companion object {
        private const val TAG = "MainActivity"
        private const val REQUEST_CAMERA_PERMISSION = 100
    }
}

