package com.example.edgedetection

import android.util.Log

class NativeProcessor {
    private external fun nativeInit(): Long
    private external fun nativeProcessFrame(
        inputBuffer: ByteArray,
        width: Int,
        height: Int,
        outputBuffer: ByteArray,
        edgeMode: Boolean
    ): Int
    private external fun nativeRelease(handle: Long)
    external fun convertYUVtoRGBA(
        yuvBuffer: ByteArray,
        width: Int,
        height: Int,
        rgbaBuffer: ByteArray
    ): Int
    
    private var nativeHandle: Long = 0
    
    init {
        System.loadLibrary("native-lib")
    }
    
    fun initialize() {
        nativeHandle = nativeInit()
        if (nativeHandle == 0L) {
            Log.e("NativeProcessor", "Failed to initialize native processor")
        }
    }
    
    fun processFrame(inputFrame: ByteArray, width: Int, height: Int): ByteArray? {
        if (nativeHandle == 0L) {
            return null
        }
        
        val outputFrame = ByteArray(width * height * 4) // RGBA
        val result = nativeProcessFrame(inputFrame, width, height, outputFrame, isEdgeMode)
        
        return if (result == 0) outputFrame else null
    }
    
    fun setEdgeMode(edgeMode: Boolean) {
        isEdgeMode = edgeMode
    }
    
    fun release() {
        if (nativeHandle != 0L) {
            nativeRelease(nativeHandle)
            nativeHandle = 0
        }
    }
    
    private var isEdgeMode = true
}

