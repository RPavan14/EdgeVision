package com.example.edgedetection

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Simple HTTP client to send frames to the web server
 * In production, this would be more robust with proper error handling
 */
class FrameServer(private val serverUrl: String = "http://10.0.2.2:8080") {
    private val isRunning = AtomicBoolean(false)
    private var sendJob: Job? = null
    
    /**
     * Start sending frames to server
     */
    fun startSendingFrames(frameData: ByteArray, width: Int, height: Int) {
        if (!isRunning.compareAndSet(false, true)) {
            return // Already running
        }
        
        sendJob = CoroutineScope(Dispatchers.IO).launch {
            while (isRunning.get()) {
                try {
                    sendFrame(frameData, width, height)
                    delay(100) // Send at ~10 FPS
                } catch (e: Exception) {
                    Log.e("FrameServer", "Error sending frame", e)
                    delay(1000) // Wait longer on error
                }
            }
        }
    }
    
    /**
     * Stop sending frames
     */
    fun stopSendingFrames() {
        isRunning.set(false)
        sendJob?.cancel()
    }
    
    /**
     * Send a single frame to the server
     */
    private fun sendFrame(frameData: ByteArray, width: Int, height: Int) {
        val url = URL("$serverUrl/api/frame")
        val connection = url.openConnection() as HttpURLConnection
        
        try {
            connection.requestMethod = "POST"
            connection.setRequestProperty("Content-Type", "application/json")
            connection.doOutput = true
            
            // Convert RGBA frame to base64
            // Note: For better performance, you could convert to PNG/JPEG first
            val base64Frame = Base64.encodeToString(frameData, Base64.NO_WRAP)
            
            // Create JSON payload
            val json = """
                {
                    "data": "$base64Frame",
                    "width": $width,
                    "height": $height,
                    "timestamp": ${System.currentTimeMillis()}
                }
            """.trimIndent()
            
            // Send data
            val outputStream: OutputStream = connection.outputStream
            outputStream.write(json.toByteArray(Charsets.UTF_8))
            outputStream.flush()
            outputStream.close()
            
            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                Log.d("FrameServer", "Frame sent successfully: ${width}x${height}")
            } else {
                Log.w("FrameServer", "Server returned: $responseCode")
            }
        } catch (e: Exception) {
            Log.e("FrameServer", "Failed to send frame", e)
            throw e
        } finally {
            connection.disconnect()
        }
    }
    
    /**
     * Send a single frame (one-time, not continuous)
     */
    suspend fun sendFrameOnce(frameData: ByteArray, width: Int, height: Int) {
        withContext(Dispatchers.IO) {
            sendFrame(frameData, width, height)
        }
    }
}

