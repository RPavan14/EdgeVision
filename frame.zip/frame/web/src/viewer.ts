/**
 * Edge Detection Web Viewer
 * Displays processed frames with FPS and resolution overlays
 */

interface FrameInfo {
    data: string; // base64 encoded image
    fps: number;
    width: number;
    height: number;
    timestamp: number;
}

class EdgeDetectionViewer {
    private canvas: HTMLCanvasElement;
    private ctx: CanvasRenderingContext2D;
    private fpsDisplay: HTMLElement;
    private resolutionDisplay: HTMLElement;
    private statusDisplay: HTMLElement;
    
    private currentFrame: FrameInfo | null = null;
    private frameCount: number = 0;
    private lastFpsUpdate: number = 0;
    private currentFps: number = 0;
    
    constructor(canvasId: string, fpsId: string, resolutionId: string, statusId: string) {
        const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
        if (!canvas) {
            throw new Error(`Canvas element with id '${canvasId}' not found`);
        }
        
        this.canvas = canvas;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            throw new Error('Failed to get 2D rendering context');
        }
        this.ctx = ctx;
        
        this.fpsDisplay = document.getElementById(fpsId)!;
        this.resolutionDisplay = document.getElementById(resolutionId)!;
        this.statusDisplay = document.getElementById(statusId)!;
        
        this.setupCanvas();
        this.loadSampleFrame();
    }
    
    private setupCanvas(): void {
        // Set canvas size
        this.canvas.width = 640;
        this.canvas.height = 480;
        
        // Set display size (CSS)
        this.canvas.style.width = '100%';
        this.canvas.style.height = 'auto';
        this.canvas.style.maxWidth = '800px';
        this.canvas.style.border = '2px solid #333';
        this.canvas.style.backgroundColor = '#000';
    }
    
    /**
     * Load a processed frame from the Android app via HTTP
     * Falls back to sample frame if server is not available
     */
    private async loadSampleFrame(): Promise<void> {
        try {
            // Try to fetch frame from server (Android app)
            const response = await fetch('/api/frame');
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.frame) {
                    // Load frame from Android app
                    this.loadFrameFromBase64(
                        data.frame.data,
                        data.frame.width,
                        data.frame.height
                    );
                    this.updateStatus(`Connected - Frame from Android app (${data.frame.width}×${data.frame.height})`);
                    
                    // Start polling for updates
                    this.startFramePolling();
                    return;
                }
            }
        } catch (error) {
            console.log('Server not available, using sample frame:', error);
        }
        
        // Fallback: Create sample frame
        this.createSampleFrame();
        this.startFrameSimulation();
        this.updateStatus('Displaying sample frame (Android app not connected)');
    }
    
    /**
     * Poll server for new frames from Android app
     */
    private startFramePolling(): void {
        const pollInterval = 100; // Poll every 100ms (10 FPS)
        
        setInterval(async () => {
            try {
                const response = await fetch('/api/frame');
                if (response.ok) {
                    const data = await response.json();
                    if (data.success && data.frame) {
                        this.loadFrameFromBase64(
                            data.frame.data,
                            data.frame.width,
                            data.frame.height
                        );
                        
                        // Update FPS counter
                        this.frameCount++;
                        const now = performance.now();
                        if (now - this.lastFpsUpdate >= 1000) {
                            this.currentFps = this.frameCount;
                            this.frameCount = 0;
                            this.lastFpsUpdate = now;
                            this.updateFpsDisplay();
                        }
                    }
                }
            } catch (error) {
                // Server unavailable, keep showing last frame
                console.debug('Frame polling error:', error);
            }
        }, pollInterval);
    }
    
    /**
     * Create a sample frame for demonstration - simulates Canny edge detection
     */
    private createSampleFrame(): void {
        const width = this.canvas.width;
        const height = this.canvas.height;
        
        // Clear canvas with dark background (simulating camera feed)
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(0, 0, width, height);
        
        // Create a more realistic scene with objects that would have edges
        // Simulate a scene with varying brightness
        const gradient = this.ctx.createRadialGradient(width/2, height/2, 50, width/2, height/2, 200);
        gradient.addColorStop(0, '#2a2a2a');
        gradient.addColorStop(1, '#0a0a0a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(0, 0, width, height);
        
        // Draw some objects that would create edges
        // Box in center
        this.ctx.fillStyle = '#3a3a3a';
        this.ctx.fillRect(width/2 - 80, height/2 - 60, 160, 120);
        
        // Circle
        this.ctx.fillStyle = '#2a2a2a';
        this.ctx.beginPath();
        this.ctx.arc(width/4, height/3, 60, 0, 2 * Math.PI);
        this.ctx.fill();
        
        // Lines
        this.ctx.strokeStyle = '#4a4a4a';
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.moveTo(0, height/2);
        this.ctx.lineTo(width, height/2);
        this.ctx.stroke();
        
        // Now apply edge detection effect - draw edges in green
        this.ctx.strokeStyle = '#00ff00'; // Green edges (Canny style)
        this.ctx.lineWidth = 1.5;
        
        // Draw edges around the box
        this.ctx.strokeRect(width/2 - 80, height/2 - 60, 160, 120);
        
        // Draw edges around the circle
        this.ctx.beginPath();
        this.ctx.arc(width/4, height/3, 60, 0, 2 * Math.PI);
        this.ctx.stroke();
        
        // Draw the horizontal line edge
        this.ctx.beginPath();
        this.ctx.moveTo(0, height/2);
        this.ctx.lineTo(width, height/2);
        this.ctx.stroke();
        
        // Add some noise/random edges (simulating texture edges)
        this.ctx.strokeStyle = '#00ff00';
        this.ctx.lineWidth = 1;
        for (let i = 0; i < 30; i++) {
            const x = Math.random() * width;
            const y = Math.random() * height;
            const size = Math.random() * 15 + 3;
            this.ctx.strokeRect(x, y, size, size);
        }
        
        // Add diagonal edges
        this.ctx.beginPath();
        this.ctx.moveTo(width * 0.1, height * 0.1);
        this.ctx.lineTo(width * 0.9, height * 0.9);
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(width * 0.9, height * 0.1);
        this.ctx.lineTo(width * 0.1, height * 0.9);
        this.ctx.stroke();
    }
    
    /**
     * Create a more detailed sample frame with better edge detection simulation
     */
    public createDetailedSampleFrame(): void {
        this.createSampleFrame();
        this.updateStatus('Sample frame loaded - Edge detection active');
    }
    
    /**
     * Simulate frame updates (in production, this would be real-time from Android app)
     */
    private startFrameSimulation(): void {
        const updateFrame = () => {
            this.frameCount++;
            const now = performance.now();
            
            // Update FPS every second
            if (now - this.lastFpsUpdate >= 1000) {
                this.currentFps = this.frameCount;
                this.frameCount = 0;
                this.lastFpsUpdate = now;
                this.updateFpsDisplay();
            }
            
            // Redraw frame with slight variations
            this.createSampleFrame();
            
            // Schedule next frame
            requestAnimationFrame(updateFrame);
        };
        
        updateFrame();
    }
    
    /**
     * Update FPS display
     */
    private updateFpsDisplay(): void {
        this.fpsDisplay.textContent = `FPS: ${this.currentFps}`;
    }
    
    /**
     * Update resolution display
     */
    private updateResolutionDisplay(): void {
        this.resolutionDisplay.textContent = 
            `Resolution: ${this.canvas.width} × ${this.canvas.height}`;
    }
    
    /**
     * Update status display
     */
    private updateStatus(message: string): void {
        this.statusDisplay.textContent = `Status: ${message}`;
    }
    
    /**
     * Load a frame from base64 data
     */
    public loadFrameFromBase64(base64Data: string, width: number, height: number): void {
        const img = new Image();
        img.onload = () => {
            this.canvas.width = width;
            this.canvas.height = height;
            this.ctx.drawImage(img, 0, 0);
            this.updateResolutionDisplay();
        };
        img.onerror = () => {
            console.error('Failed to load image from base64');
            this.updateStatus('Error loading frame');
        };
        img.src = `data:image/png;base64,${base64Data}`;
    }
    
    /**
     * Initialize the viewer
     */
    public initialize(): void {
        this.updateResolutionDisplay();
        this.updateFpsDisplay();
        this.updateStatus('Sample frame loaded - Edge detection active');
        // Create initial frame
        this.createSampleFrame();
    }
    
    /**
     * Reload sample frame (for button click)
     */
    public async reloadSampleFrame(): Promise<void> {
        try {
            // Try to fetch latest frame from server
            const response = await fetch('/api/frame');
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.frame) {
                    this.loadFrameFromBase64(
                        data.frame.data,
                        data.frame.width,
                        data.frame.height
                    );
                    this.updateStatus('Frame reloaded from Android app');
                    return;
                }
            }
        } catch (error) {
            console.log('Server not available, reloading sample frame');
        }
        
        // Fallback: reload sample frame
        this.createDetailedSampleFrame();
        this.updateStatus('Sample frame reloaded');
    }
}

// Initialize viewer when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    try {
        const viewer = new EdgeDetectionViewer(
            'frameCanvas',
            'fpsDisplay',
            'resolutionDisplay',
            'statusDisplay'
        );
        viewer.initialize();
        
        // Make viewer available globally for debugging
        (window as any).edgeDetectionViewer = viewer;
    } catch (error) {
        console.error('Failed to initialize viewer:', error);
    }
});

// Export for module usage
export { EdgeDetectionViewer, FrameInfo };

