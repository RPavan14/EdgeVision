# Android App ↔ Web Viewer Integration Guide

This guide explains how to connect the Android app to the web viewer for real-time frame streaming.

## Architecture

```
Android App (Camera) 
    ↓
Process Frame (OpenCV)
    ↓
Send via HTTP POST
    ↓
Node.js Server (web/server.js)
    ↓
Web Viewer (fetch /api/frame)
    ↓
Display Frame
```

## Setup Instructions

### Step 1: Start the Web Server

```bash
cd web
npm install  # If not already done
npm run build  # Compile TypeScript
npm run serve  # Start server on http://localhost:8080
```

The server will:
- Listen on port 8080
- Accept POST requests at `/api/frame` from Android app
- Serve the web viewer at `http://localhost:8080`
- Provide GET `/api/frame` for the viewer to fetch frames

### Step 2: Configure Android App

#### For Android Emulator:
The app is already configured to use `http://10.0.2.2:8080` (emulator's special IP for host machine).

#### For Physical Device:
1. Find your computer's IP address:
   ```bash
   # Windows
   ipconfig
   # Look for IPv4 Address (e.g., 192.168.1.100)
   
   # Linux/Mac
   ifconfig
   # Look for inet address
   ```

2. Update `MainActivity.kt`:
   ```kotlin
   // Replace this line:
   frameServer = FrameServer("http://10.0.2.2:8080")
   
   // With your computer's IP:
   frameServer = FrameServer("http://192.168.1.100:8080") // Replace 100 with your IP
   ```

3. Ensure your phone and computer are on the same WiFi network

### Step 3: Enable Frame Sending in Android App

In `MainActivity.kt`, set `sendToServer = true`:

```kotlin
private var sendToServer = true // Enable sending frames to server
```

Or add a toggle button in the UI to enable/disable it.

### Step 4: Test the Connection

1. **Start the web server** (Step 1)
2. **Open web viewer**: `http://localhost:8080`
3. **Run Android app** on device/emulator
4. **Grant camera permission**
5. **Check web viewer** - frames should appear!

## API Endpoints

### POST /api/frame
Send a frame from Android app to server.

**Request Body:**
```json
{
    "data": "base64_encoded_image_data",
    "width": 640,
    "height": 480,
    "timestamp": 1234567890
}
```

**Response:**
```json
{
    "success": true,
    "message": "Frame received"
}
```

### GET /api/frame
Get the latest frame from server (used by web viewer).

**Response:**
```json
{
    "success": true,
    "frame": {
        "data": "base64_encoded_image_data",
        "width": 640,
        "height": 480,
        "timestamp": 1234567890
    },
    "timestamp": 1234567890
}
```

### GET /api/status
Get server status.

**Response:**
```json
{
    "success": true,
    "hasFrame": true,
    "lastUpdate": 1234567890,
    "uptime": 3600
}
```

## Troubleshooting

### Android App Can't Connect to Server

**Emulator:**
- Use `10.0.2.2` to access host machine
- Ensure server is running on port 8080
- Check firewall isn't blocking

**Physical Device:**
- Verify phone and computer are on same WiFi
- Use computer's actual IP address (not localhost)
- Check firewall allows port 8080
- Try disabling Windows Firewall temporarily

### Web Viewer Shows "Android app not connected"

- Check server is running: `npm run serve`
- Verify Android app is sending frames (check logcat)
- Open browser console for errors
- Check network tab in browser DevTools

### Frames Not Updating

- Check Android app is processing frames (FPS counter should update)
- Verify `sendToServer = true` in MainActivity
- Check server logs for incoming requests
- Verify frame data is valid base64

## Performance Considerations

- **Frame Rate**: Currently sends at ~10 FPS (adjustable in `FrameServer.kt`)
- **Resolution**: 640x480 recommended for good performance
- **Network**: Ensure stable WiFi connection
- **Base64 Encoding**: Adds ~33% overhead, but simpler than binary

## Future Enhancements

- WebSocket support for lower latency
- Binary frame transmission (more efficient)
- Frame compression (JPEG/PNG)
- Multiple client support
- Authentication/security
- Frame buffering for smooth playback

## Testing

1. **Test Server Alone:**
   ```bash
   # Send test frame
   curl -X POST http://localhost:8080/api/frame \
     -H "Content-Type: application/json" \
     -d '{"data":"test","width":640,"height":480,"timestamp":1234567890}'
   
   # Get frame
   curl http://localhost:8080/api/frame
   ```

2. **Test Web Viewer:**
   - Open `http://localhost:8080`
   - Should show sample frame if no Android app connected
   - Should show real frames when Android app is running

3. **Test Android App:**
   - Check logcat for "Frame sent successfully" messages
   - Verify frames are being processed (FPS counter updates)

