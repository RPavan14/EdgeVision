# Edge Detection Web Viewer

TypeScript-based web viewer for displaying processed edge detection frames from the Android app.

## Features

- Real-time frame display (simulated)
- FPS counter overlay
- Resolution display
- Status information
- Modern, responsive UI

## Setup

```bash
# Install dependencies
npm install

# Build TypeScript
npm run build

# Serve locally
npm run serve
```

Then open `http://localhost:8080` in your browser.

## Development

```bash
# Watch mode for development
npm run watch
```

## Integration with Android App

In production, the web viewer would receive frames from the Android app via:

1. **HTTP Endpoint**: POST frames as base64-encoded images
2. **WebSocket**: Real-time frame streaming
3. **Static Files**: Pre-saved processed frames

Example integration:

```typescript
// Load frame from Android app
const response = await fetch('http://android-device-ip:8080/api/frame');
const frameData = await response.json();
viewer.loadFrameFromBase64(frameData.image, frameData.width, frameData.height);
```

