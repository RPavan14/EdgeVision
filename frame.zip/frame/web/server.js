/**
 * Simple HTTP server for receiving frames from Android app
 * and serving them to the web viewer
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 8080;
let currentFrame = null;
let frameUpdateTime = null;

// Create HTTP server
const server = http.createServer((req, res) => {
    const url = req.url;
    
    // CORS headers
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    
    if (req.method === 'OPTIONS') {
        res.writeHead(200);
        res.end();
        return;
    }
    
    // API endpoint: POST /api/frame - Receive frame from Android app
    if (url === '/api/frame' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        
        req.on('end', () => {
            try {
                const frameData = JSON.parse(body);
                currentFrame = frameData;
                frameUpdateTime = Date.now();
                
                console.log(`Frame received: ${frameData.width}x${frameData.height} at ${new Date().toISOString()}`);
                
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true, message: 'Frame received' }));
            } catch (error) {
                console.error('Error parsing frame data:', error);
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: error.message }));
            }
        });
        return;
    }
    
    // API endpoint: GET /api/frame - Get latest frame
    if (url === '/api/frame' && req.method === 'GET') {
        if (currentFrame) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
                success: true,
                frame: currentFrame,
                timestamp: frameUpdateTime
            }));
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: false, message: 'No frame available' }));
        }
        return;
    }
    
    // API endpoint: GET /api/status - Get server status
    if (url === '/api/status' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            success: true,
            hasFrame: currentFrame !== null,
            lastUpdate: frameUpdateTime,
            uptime: process.uptime()
        }));
        return;
    }
    
    // Serve static files
    let filePath = path.join(__dirname, 'dist', url === '/' ? 'index.html' : url);
    
    // Security: prevent directory traversal
    if (!filePath.startsWith(path.join(__dirname, 'dist'))) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
    }
    
    // Check if file exists
    fs.stat(filePath, (err, stats) => {
        if (err || !stats.isFile()) {
            // Try index.html for directory requests
            if (url === '/' || url.endsWith('/')) {
                filePath = path.join(__dirname, 'dist', 'index.html');
            } else {
                res.writeHead(404);
                res.end('Not Found');
                return;
            }
        }
        
        // Determine content type
        const ext = path.extname(filePath);
        const contentTypes = {
            '.html': 'text/html',
            '.js': 'application/javascript',
            '.css': 'text/css',
            '.json': 'application/json',
            '.png': 'image/png',
            '.jpg': 'image/jpeg',
            '.gif': 'image/gif'
        };
        
        const contentType = contentTypes[ext] || 'application/octet-stream';
        
        // Read and serve file
        fs.readFile(filePath, (err, data) => {
            if (err) {
                res.writeHead(500);
                res.end('Internal Server Error');
                return;
            }
            
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(data);
        });
    });
});

server.listen(PORT, () => {
    console.log(`\n🚀 Edge Detection Server running on http://localhost:${PORT}`);
    console.log(`📡 Ready to receive frames from Android app`);
    console.log(`🌐 Web viewer available at http://localhost:${PORT}\n`);
    console.log('API Endpoints:');
    console.log(`  POST /api/frame  - Send frame from Android app`);
    console.log(`  GET  /api/frame  - Get latest frame`);
    console.log(`  GET  /api/status - Get server status\n`);
});

// Handle errors
server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} is already in use. Try a different port.`);
    } else {
        console.error('Server error:', err);
    }
    process.exit(1);
});

