# Real-Time Edge Detection Viewer

A modular Android application that captures camera frames, processes them using OpenCV C++ (Canny edge detection), and renders the results in real-time using OpenGL ES 2.0. Includes a TypeScript web viewer for displaying processed frames.

## Architecture

```
┌─────────────────┐
│  Camera2 API    │
│  (TextureView)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   JNI Bridge    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐      ┌──────────────┐
│  OpenCV C++     │─────▶│  OpenGL ES   │
│  Edge Detection │      │  2.0 Render  │
└─────────────────┘      └──────────────┘
```

## Features

- ✅ Real-time camera capture using Camera2 API
- ✅ Native C++ OpenCV processing (Canny edge detection + grayscale)
- ✅ OpenGL ES 2.0 texture rendering (target: 10-15 FPS)
- ✅ JNI bridge for Java ↔ C++ communication
- ✅ TypeScript web viewer with FPS/resolution overlay
- ✅ Toggle between raw/edge output
- ✅ FPS counter on Android UI

## Prerequisites

### Android Development
- Android Studio (latest stable)
- Android SDK (API 24+)
- Android NDK (r21+)
- OpenCV Android SDK (4.5.0+)

### Web Development
- Node.js (v14+)
- TypeScript compiler (`npm install -g typescript`)

## Quick Start

### Android App (Automatic Setup)
1. **Download OpenCV**: Get OpenCV Android SDK from [opencv.org/releases](https://opencv.org/releases/)
2. **Configure**: Copy `local.properties.template` to `local.properties` and set your paths
3. **Open in Android Studio**: File → Open → Select `frame` folder
4. **Run**: Click Run button (▶) or press `Shift+F10`
5. **Grant Camera Permission**: App automatically starts capturing and processing frames!

**The app automatically:**
- ✅ Accesses camera
- ✅ Captures frames continuously
- ✅ Processes with OpenCV edge detection
- ✅ Sends frames to web viewer (if server is running)
- ✅ Displays results in real-time

### Web Viewer (Optional)
```bash
cd web
npm install
npm run build
npm run serve
# Open http://localhost:8080 to see frames from Android app
```

**For detailed instructions, see [QUICK_START.md](QUICK_START.md), [SETUP.md](SETUP.md), or [AUTOMATIC_SETUP.md](AUTOMATIC_SETUP.md)**

## Setup Instructions

### 1. Clone and Prepare OpenCV

1. Download OpenCV Android SDK from [opencv.org/releases](https://opencv.org/releases/)
2. Extract to a location (e.g., `C:\OpenCV-android-sdk`)
3. Note the path to `sdk/native/jni/include` and `sdk/native/libs`

### 2. Configure Android Project

1. Open `local.properties` and add:
   ```properties
   sdk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk
   ndk.dir=C\:\\Users\\YourName\\AppData\\Local\\Android\\Sdk\\ndk\\<version>
   opencv.dir=C\:\\OpenCV-android-sdk
   ```

2. Update `app/build.gradle` with your OpenCV path

3. Sync Gradle

### 3. Build Native Code

```bash
# From project root
cd app
./gradlew assembleDebug
```

### 4. Run Android App

1. Connect Android device (API 24+) or start emulator
2. Enable USB debugging
3. Run: `./gradlew installDebug`

### 5. Build Web Viewer

```bash
cd web
npm install
npm run build
# Open dist/index.html in browser
```

## Project Structure

```
frame/
├── app/                    # Android application
│   ├── src/main/
│   │   ├── java/.../      # MainActivity, CameraHandler, etc.
│   │   ├── res/            # Layouts, strings
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── jni/                    # Native C++ code
│   ├── CMakeLists.txt
│   ├── native-lib.cpp      # JNI bridge
│   └── edge_detector.cpp   # OpenCV processing
├── gl/                     # OpenGL ES 2.0
│   ├── gl_renderer.cpp
│   └── shaders/
│       ├── vertex.glsl
│       └── fragment.glsl
├── web/                    # TypeScript web viewer
│   ├── src/
│   │   └── viewer.ts
│   ├── dist/
│   └── package.json
└── README.md
```

## Usage

### Android App

1. Launch the app
2. Grant camera permission when prompted
3. View real-time edge detection
4. Toggle between raw/edge using the button
5. FPS counter shows in top-left corner

### Web Viewer

1. Build the TypeScript: `cd web && npm run build`
2. Open `web/dist/index.html` in a browser
3. The viewer displays a sample processed frame with overlays

## Technical Details

### JNI Bridge

- `Java_com_example_edgedetection_NativeProcessor_processFrame()` - Main entry point
- Frame data passed as byte arrays (YUV420 format)
- Returns processed frame as RGBA byte array

### OpenCV Processing

- Input: YUV420 camera frame
- Conversion: YUV → Grayscale → Canny edge detection
- Output: RGBA texture data

### OpenGL ES 2.0

- Vertex shader: Full-screen quad
- Fragment shader: Texture sampling
- Texture format: GL_RGBA, GL_UNSIGNED_BYTE

## Performance

- Target FPS: 10-15 FPS
- Resolution: 640x480 (configurable)
- Processing: Native C++ for optimal performance

## Troubleshooting

### NDK Issues
- Ensure NDK version matches `build.gradle`
- Check `local.properties` paths are correct

### OpenCV Issues
- Verify OpenCV SDK path in `build.gradle`
- Ensure native libraries are linked correctly

### Camera Issues
- Check AndroidManifest.xml permissions
- Verify device supports Camera2 API

## Documentation

- **[SETUP.md](SETUP.md)**: Detailed setup and configuration guide
- **[IMPLEMENTATION.md](IMPLEMENTATION.md)**: Architecture and implementation details
- **[LICENSE](LICENSE)**: MIT License

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes with clear commit messages
4. Submit a pull request

## License

MIT License - See [LICENSE](LICENSE) file for details

## Screenshots

*Add screenshots of the app and web viewer here*

## Acknowledgments

- OpenCV for computer vision library
- Android NDK for native development
- OpenGL ES for graphics rendering

