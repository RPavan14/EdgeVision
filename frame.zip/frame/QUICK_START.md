# Quick Start Guide - How to Run

## Prerequisites Check

Before running, ensure you have:
- ✅ Android Studio installed
- ✅ Android SDK (API 24+)
- ✅ Android NDK (r21+)
- ✅ OpenCV Android SDK downloaded and extracted
- ✅ Node.js installed (for web viewer)

## Step 1: Configure OpenCV Path

1. **Download OpenCV Android SDK**
   - Visit: https://opencv.org/releases/
   - Download the Android pack (e.g., `opencv-4.x.x-android-sdk.zip`)
   - Extract to a location like `C:\OpenCV-android-sdk`

2. **Create local.properties**
   ```bash
   # Copy the template
   copy local.properties.template local.properties
   ```

3. **Edit local.properties** with your paths:
   ```properties
   sdk.dir=C\:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk
   ndk.dir=C\:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk\\ndk\\YOUR_NDK_VERSION
   opencv.dir=C\:\\OpenCV-android-sdk
   ```
   
   **To find your paths:**
   - SDK: Usually in `%LOCALAPPDATA%\Android\Sdk`
   - NDK: Check `%LOCALAPPDATA%\Android\Sdk\ndk\` for version number
   - OpenCV: Where you extracted the SDK

## Step 2: Run Android App

### Option A: Using Android Studio (Recommended)

1. **Open Project**
   - Launch Android Studio
   - Click `File → Open`
   - Navigate to the `frame` folder and select it
   - Click `OK`

2. **Wait for Gradle Sync**
   - Android Studio will automatically sync Gradle
   - Wait for "Gradle sync finished" message
   - If errors appear, check OpenCV path in `local.properties`

3. **Connect Device or Start Emulator**
   
   **Physical Device:**
   - Enable USB debugging on your Android device
   - Connect via USB
   - Allow USB debugging when prompted
   - Device should appear in Android Studio

   **Emulator:**
   - Click `Tools → Device Manager`
   - Click `Create Device`
   - Select a device (e.g., Pixel 5)
   - Select system image (API 24+)
   - Finish setup and start emulator

4. **Build and Run**
   - Click the green `Run` button (▶) or press `Shift+F10`
   - Select your device/emulator
   - Wait for build to complete
   - App will install and launch automatically

5. **Grant Permissions**
   - When app opens, it will request camera permission
   - Click `Allow`
   - You should see the camera feed with edge detection!

### Option B: Using Command Line

```bash
# Navigate to project root
cd C:\MAF\frame

# Build the app
.\gradlew assembleDebug

# Install on connected device
.\gradlew installDebug

# Or build and install in one command
.\gradlew installDebug
```

**Note**: On Windows, use `.\gradlew` or `gradlew.bat`. On Linux/Mac, use `./gradlew`.

## Step 3: Run Web Viewer

1. **Navigate to web directory**
   ```bash
   cd web
   ```

2. **Install dependencies** (if not already done)
   ```bash
   npm install
   ```

3. **Build TypeScript** (if not already done)
   ```bash
   npm run build
   ```

4. **Start local server**
   ```bash
   npm run serve
   ```
   
   This will start a server at `http://localhost:8080`

5. **Open in browser**
   - Open your web browser
   - Navigate to: `http://localhost:8080`
   - You should see the web viewer with sample frame

## Troubleshooting

### Android App Won't Build

**Error: OpenCV not found**
```
Solution:
1. Verify opencv.dir in local.properties points to the correct directory
2. Check that OpenCV SDK is fully extracted
3. Verify path structure: <opencv-dir>/sdk/native/jni/OpenCVConfig.cmake exists
```

**Error: NDK not found**
```
Solution:
1. Install NDK via Android Studio: Tools → SDK Manager → SDK Tools → NDK
2. Update ndk.dir in local.properties with correct version
```

**Error: Gradle sync failed**
```
Solution:
1. File → Invalidate Caches / Restart
2. Check internet connection (Gradle downloads dependencies)
3. Verify all paths in local.properties are correct
```

### App Crashes on Launch

**Check logcat:**
```bash
adb logcat | grep -i error
```

**Common issues:**
- Camera permission not granted → Grant in app settings
- Device doesn't support Camera2 API → Use emulator or newer device
- Native library not found → Rebuild project

### Web Viewer Not Loading

**Port already in use:**
```bash
# Use different port
npx http-server dist -p 8081
```

**TypeScript not compiled:**
```bash
cd web
npm run build
```

## Testing the App

### Android App Features to Test:

1. ✅ **Camera opens** - Should see camera feed
2. ✅ **Edge detection works** - Edges should be visible
3. ✅ **Toggle button** - Switches between edge/grayscale
4. ✅ **FPS counter** - Updates in top-left corner
5. ✅ **Performance** - Should achieve 10-15 FPS

### Web Viewer Features to Test:

1. ✅ **Page loads** - Should see viewer interface
2. ✅ **FPS display** - Shows FPS counter
3. ✅ **Resolution display** - Shows frame resolution
4. ✅ **Sample frame** - Displays demo edge detection frame

## Next Steps

Once running:
- Try different edge detection parameters
- Adjust camera resolution for better performance
- Integrate web viewer with Android app (HTTP/WebSocket)
- Add frame saving functionality

## Getting Help

If you encounter issues:
1. Check `SETUP.md` for detailed setup instructions
2. Review `IMPLEMENTATION.md` for architecture details
3. Check Android Studio's logcat for error messages
4. Verify all prerequisites are installed correctly

