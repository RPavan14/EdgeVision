# How to Connect Android App to Web Viewer

## Quick Start

### 1. Start the Web Server

```bash
cd web
npm run serve
```

You should see:
```
🚀 Edge Detection Server running on http://localhost:8080
📡 Ready to receive frames from Android app
🌐 Web viewer available at http://localhost:8080
```

### 2. Enable Frame Sending in Android App

In `app/src/main/java/com/example/edgedetection/MainActivity.kt`, change:

```kotlin
private var sendToServer = false // Change this to true
```

To:

```kotlin
private var sendToServer = true // Enable sending frames
```

### 3. Configure Server URL

**For Android Emulator:**
Already configured! Uses `http://10.0.2.2:8080`

**For Physical Device:**
1. Find your computer's IP:
   ```bash
   # Windows
   ipconfig
   # Look for "IPv4 Address" (e.g., 192.168.1.100)
   ```

2. Update `MainActivity.kt` line 89:
   ```kotlin
   frameServer = FrameServer("http://192.168.1.100:8080") // Replace 100 with your IP
   ```

3. Ensure phone and computer are on the same WiFi network

### 4. Run Android App

1. Build and run the app
2. Grant camera permission
3. Frames will automatically be sent to the server

### 5. View in Browser

Open `http://localhost:8080` in your browser. You should see:
- Real-time frames from Android app
- FPS counter updating
- Status showing "Connected - Frame from Android app"

## What Happens

1. **Android App** captures camera frames
2. **Processes** them with OpenCV (edge detection)
3. **Sends** processed frames to server via HTTP POST
4. **Web Server** stores the latest frame
5. **Web Viewer** polls server every 100ms to get new frames
6. **Displays** frames in real-time

## Troubleshooting

### "Android app not connected" in web viewer

- ✅ Check server is running (`npm run serve`)
- ✅ Verify `sendToServer = true` in MainActivity
- ✅ Check Android app logcat for "Frame sent successfully"
- ✅ Verify server URL is correct (10.0.2.2 for emulator, your IP for device)

### Frames not appearing

- ✅ Check browser console for errors (F12)
- ✅ Verify frames are being processed (FPS counter in Android app updates)
- ✅ Check server logs for incoming POST requests
- ✅ Try reloading the page

### Connection errors

**Emulator:**
- Use `10.0.2.2:8080` (special IP for host machine)
- Ensure server is running on port 8080

**Physical Device:**
- Use your computer's actual IP address
- Both devices must be on same WiFi
- Check firewall isn't blocking port 8080

## Testing Without Android App

The web viewer will automatically show a sample frame if the Android app isn't connected. This is perfect for testing the UI!

## Performance

- **Frame Rate**: ~10 FPS (adjustable in `FrameServer.kt`)
- **Resolution**: 640×480 (configurable)
- **Latency**: ~100-200ms (depends on network)

## Next Steps

See [web/INTEGRATION.md](web/INTEGRATION.md) for detailed API documentation and advanced configuration.

