# Automatic Camera & Frame Processing Setup

The Android app is now configured to **automatically**:
1. ✅ Access the camera when launched
2. ✅ Capture frames continuously
3. ✅ Process frames with OpenCV (edge detection)
4. ✅ Send processed frames to web viewer
5. ✅ Display frames in real-time

## No Manual Steps Required!

### What Happens Automatically:

1. **App Launches** → Requests camera permission
2. **Permission Granted** → Camera opens automatically
3. **Frames Captured** → Processed with OpenCV edge detection
4. **Frames Sent** → Automatically sent to web server (if running)
5. **Display** → Shown on device screen via OpenGL

### To See It Work:

#### Step 1: Start Web Server (Optional - for web viewer)
```bash
cd web
npm run serve
```

#### Step 2: Run Android App
- Build and install the app
- Grant camera permission when prompted
- **That's it!** Everything else is automatic

#### Step 3: View Results
- **On Device**: See processed frames in the app
- **In Browser**: Open `http://localhost:8080` to see frames from the app

## Configuration

### Frame Sending (Already Enabled)
```kotlin
private var sendToServer = true // Automatically sends frames
```

### Server URL
**For Emulator** (default):
```kotlin
frameServer = FrameServer("http://10.0.2.2:8080")
```

**For Physical Device**:
1. Find your computer's IP: `ipconfig` (Windows) or `ifconfig` (Linux/Mac)
2. Update `MainActivity.kt` line 89:
```kotlin
frameServer = FrameServer("http://192.168.1.XXX:8080") // Replace XXX
```

## What You'll See

### In Android App:
- Camera feed with edge detection applied
- FPS counter in top-left corner
- Toggle button to switch edge/grayscale modes
- Real-time processing at ~10-15 FPS

### In Web Viewer:
- Real-time frames from Android app
- FPS and resolution overlays
- Status showing connection state

## Troubleshooting

### Camera Not Opening
- ✅ Grant camera permission in app settings
- ✅ Check device supports Camera2 API
- ✅ Restart the app

### Frames Not Sending to Web Viewer
- ✅ Check web server is running: `npm run serve`
- ✅ Verify server URL is correct
- ✅ Check both devices on same WiFi (for physical device)
- ✅ Check logcat for "Frame sent successfully" messages

### Web Viewer Shows "Android app not connected"
- ✅ This is normal if web server isn't running
- ✅ Start web server: `cd web && npm run serve`
- ✅ Refresh browser page
- ✅ Verify `sendToServer = true` in MainActivity

## Performance

- **Frame Rate**: 10-15 FPS (target)
- **Resolution**: 640×480 (configurable)
- **Processing**: Real-time edge detection
- **Network**: Frames sent at ~10 FPS to web server

## Customization

### Change Resolution
In `MainActivity.kt`, modify `openCamera()`:
```kotlin
val previewSize = streamConfigurationMap?.getOutputSizes(ImageFormat.YUV_420_888)
    ?.firstOrNull { it.width <= 1280 && it.height <= 720 } // Adjust max resolution
```

### Disable Frame Sending
Set `sendToServer = false` in MainActivity (line 41)

### Adjust Edge Detection Parameters
In `app/src/main/jni/edge_detector.cpp`:
```cpp
lowThreshold = 50.0;   // Lower = more edges detected
highThreshold = 150.0;  // Adjust for sensitivity
```

## That's It!

The app now works completely automatically. Just:
1. Run the app
2. Grant camera permission
3. Watch the magic happen! ✨

No manual frame loading, no extra steps - everything is automatic!

