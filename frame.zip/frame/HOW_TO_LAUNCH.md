# How to Launch the Project

## Quick Launch Guide

### Option 1: Android App Only (Simplest)

1. **Open in Android Studio**
   - Launch Android Studio
   - `File → Open` → Select the `frame` folder
   - Wait for Gradle sync to complete

2. **Run the App**
   - Click the green **Run** button (▶) or press `Shift+F10`
   - Select your device/emulator
   - Grant camera permission when prompted
   - **Done!** The app will automatically capture and process frames

### Option 2: Android App + Web Viewer

#### Step 1: Start Web Server

**Open a terminal/command prompt and run:**

```bash
# Navigate to web directory
cd C:\MAF\frame\web

# Start the server
npm run serve
```

You should see:
```
🚀 Edge Detection Server running on http://localhost:8080
📡 Ready to receive frames from Android app
🌐 Web viewer available at http://localhost:8080
```

**Keep this terminal open!**

#### Step 2: Launch Android App

1. **Open in Android Studio**
   - `File → Open` → Select `frame` folder
   - Wait for Gradle sync

2. **Run the App**
   - Click **Run** button (▶)
   - Select device/emulator
   - Grant camera permission

#### Step 3: Open Web Viewer

- Open your browser
- Go to: `http://localhost:8080`
- You'll see real-time frames from the Android app!

## Detailed Steps

### Prerequisites Check

Before launching, make sure you have:

- ✅ **Android Studio** installed
- ✅ **OpenCV SDK** downloaded and extracted
- ✅ **local.properties** configured (see below)
- ✅ **Node.js** installed (for web viewer only)

### Configure local.properties

1. **Copy template:**
   ```bash
   # From project root (C:\MAF\frame)
   copy local.properties.template local.properties
   ```

2. **Edit local.properties** with your paths:
   ```properties
   sdk.dir=C\:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk
   ndk.dir=C\:\\Users\\YOUR_USERNAME\\AppData\\Local\\Android\\Sdk\\ndk\\YOUR_NDK_VERSION
   opencv.dir=C\:\\OpenCV-android-sdk
   ```

### Launch Android App

#### Method 1: Android Studio (Recommended)

1. Open Android Studio
2. `File → Open` → Navigate to `C:\MAF\frame`
3. Click `OK`
4. Wait for Gradle sync (bottom right corner)
5. Connect device or start emulator
6. Click **Run** button (▶) or press `Shift+F10`
7. Select your device
8. Grant camera permission when prompted

#### Method 2: Command Line

```bash
# From project root
cd C:\MAF\frame

# Build and install
.\gradlew installDebug

# Or just build
.\gradlew assembleDebug
```

### Launch Web Viewer

#### Step 1: Navigate to Web Directory

```bash
cd C:\MAF\frame\web
```

#### Step 2: Install Dependencies (First Time Only)

```bash
npm install
```

#### Step 3: Build TypeScript (If Needed)

```bash
npm run build
```

#### Step 4: Start Server

```bash
npm run serve
```

#### Step 5: Open Browser

- Go to: `http://localhost:8080`
- You should see the web viewer!

## Troubleshooting

### "npm run serve" Error - Wrong Directory

**Error:** `Could not read package.json`

**Solution:** Make sure you're in the `web` directory:
```bash
cd C:\MAF\frame\web
npm run serve
```

### Android App Won't Build

**Error:** OpenCV not found

**Solution:**
1. Check `local.properties` has correct `opencv.dir` path
2. Verify OpenCV SDK is extracted completely
3. Path should point to directory containing `sdk` folder

**Error:** NDK not found

**Solution:**
1. Install NDK via Android Studio: `Tools → SDK Manager → SDK Tools → NDK`
2. Update `ndk.dir` in `local.properties`

### Web Server Won't Start

**Error:** Port 8080 already in use

**Solution:**
- Close other applications using port 8080
- Or change port in `web/server.js` (line 7)

**Error:** Module not found

**Solution:**
```bash
cd web
npm install
```

### Camera Not Working

**Error:** Camera permission denied

**Solution:**
- Grant permission in app settings
- Or reinstall the app

**Error:** Camera doesn't open

**Solution:**
- Check device supports Camera2 API
- Try restarting the app
- Check logcat for errors: `adb logcat | grep -i error`

## Quick Reference

### Android App
```bash
# Build
.\gradlew assembleDebug

# Install
.\gradlew installDebug

# Clean
.\gradlew clean
```

### Web Viewer
```bash
# Navigate
cd web

# Install (first time)
npm install

# Build
npm run build

# Serve
npm run serve
```

## What to Expect

### Android App
- Opens camera automatically
- Shows edge detection in real-time
- FPS counter updates
- Toggle button works

### Web Viewer
- Shows sample frame if app not connected
- Shows real frames if app is running
- FPS and resolution overlays
- Status indicator

## Next Steps

Once launched:
- ✅ Test edge detection
- ✅ Try toggle button
- ✅ Check FPS performance
- ✅ View frames in web browser

For more details, see:
- [QUICK_START.md](QUICK_START.md) - Quick setup
- [SETUP.md](SETUP.md) - Detailed setup
- [AUTOMATIC_SETUP.md](AUTOMATIC_SETUP.md) - Automatic features

