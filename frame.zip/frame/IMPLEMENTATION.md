# Implementation Guide

This document explains how the Real-Time Edge Detection Viewer is implemented.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Android Application                       │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐ │
│  │ Camera2 API  │───▶│ ImageReader  │───▶│ MainActivity │ │
│  │              │    │              │    │              │ │
│  └──────────────┘    └──────────────┘    └──────┬───────┘ │
│                                                   │         │
│  ┌──────────────┐    ┌──────────────┐            │         │
│  │ OpenGL ES 2.0│◀───│ EdgeGLRenderer│◀──────────┘         │
│  │              │    │              │                    │
│  └──────────────┘    └──────────────┘                    │
└─────────────────────────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                    JNI Bridge Layer                         │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐ │
│  │ native-lib   │───▶│ EdgeDetector │───▶│ GLRenderer   │ │
│  │              │    │  (OpenCV)    │    │  (OpenGL)     │ │
│  └──────────────┘    └──────────────┘    └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Component Details

### 1. Camera Capture (MainActivity.kt)

**Technology**: Camera2 API with ImageReader

**Flow**:
1. Request camera permission
2. Open camera device using CameraManager
3. Create ImageReader for YUV_420_888 format
4. Set up capture session
5. Process frames as they arrive

**Key Code**:
```kotlin
imageReader = ImageReader.newInstance(
    frameWidth, frameHeight, ImageFormat.YUV_420_888, 2
)
imageReader?.setOnImageAvailableListener(imageAvailableListener, backgroundHandler)
```

### 2. Frame Processing Pipeline

**Step 1: YUV to RGBA Conversion**
- Input: YUV_420_888 format from camera
- Process: Convert to NV21, then to RGBA using OpenCV
- Location: `native-lib.cpp::convertYUVtoRGBA()`

**Step 2: Edge Detection**
- Input: RGBA frame
- Process: 
  - Convert RGBA → BGR (OpenCV format)
  - Convert BGR → Grayscale
  - Apply Canny edge detection (if edge mode)
  - Convert back to RGBA
- Location: `edge_detector.cpp::processFrame()`

**Step 3: OpenGL Rendering**
- Input: Processed RGBA frame
- Process: Upload to OpenGL texture, render full-screen quad
- Location: `EdgeGLRenderer.kt::onDrawFrame()`

### 3. Native Code Structure

#### JNI Bridge (native-lib.cpp)
- `nativeInit()`: Initialize edge detector
- `nativeProcessFrame()`: Process frame through OpenCV
- `convertYUVtoRGBA()`: Color space conversion

#### Edge Detector (edge_detector.cpp)
- Uses OpenCV C++ API
- Canny edge detection with configurable thresholds
- Grayscale mode option

#### OpenGL Renderer (gl_renderer.cpp)
- Currently minimal (main rendering in Java/Kotlin)
- Provides shader compilation utilities

### 4. OpenGL ES 2.0 Rendering

**Vertex Shader**:
```glsl
attribute vec4 aPosition;
attribute vec2 aTexCoord;
varying vec2 vTexCoord;
void main() {
    gl_Position = aPosition;
    vTexCoord = aTexCoord;
}
```

**Fragment Shader**:
```glsl
precision mediump float;
uniform sampler2D uTexture;
varying vec2 vTexCoord;
void main() {
    gl_FragColor = texture2D(uTexture, vTexCoord);
}
```

**Rendering**:
- Full-screen quad (-1 to 1 in NDC)
- Texture coordinates (0,0) to (1,1)
- GL_TRIANGLE_STRIP for efficiency

### 5. Web Viewer

**Technology**: TypeScript + HTML5 Canvas

**Features**:
- Displays sample processed frame
- FPS counter overlay
- Resolution display
- Status information

**Future Integration**:
- HTTP endpoint: POST frames as base64
- WebSocket: Real-time streaming
- Static file serving: Pre-saved frames

## Data Flow

```
Camera Frame (YUV_420_888)
    ↓
ImageReader callback
    ↓
Convert YUV → RGBA (native)
    ↓
Process Frame (OpenCV Canny)
    ↓
Update OpenGL Texture
    ↓
Render Frame (GLSurfaceView)
    ↓
Display on Screen
```

## Performance Considerations

### Target: 10-15 FPS

**Bottlenecks**:
1. YUV to RGBA conversion
2. OpenCV processing (Canny edge detection)
3. Texture upload to GPU
4. Memory allocations

**Optimizations**:
1. **Pre-allocate buffers**: Reuse ByteArrays
2. **Reduce resolution**: 640x480 instead of full camera resolution
3. **Skip frames**: Process every 2nd or 3rd frame
4. **Native conversion**: YUV→RGBA in native code (already done)
5. **Threading**: Background thread for processing (already done)

### Memory Management

- **ImageReader**: Max 2 images in queue
- **ByteArrays**: Reused where possible
- **OpenCV Mats**: Reused, not reallocated per frame
- **OpenGL Textures**: Single texture, updated in place

## Threading Model

```
Main Thread (UI)
    ├── Camera setup
    ├── Permission handling
    └── UI updates (FPS counter)

Background Thread (CameraBackground)
    ├── ImageReader callbacks
    ├── YUV→RGBA conversion
    ├── OpenCV processing
    └── Texture updates

OpenGL Thread (GLSurfaceView)
    └── Rendering
```

## Error Handling

1. **Camera errors**: Logged, camera closed gracefully
2. **OpenCV errors**: Caught, returns error code
3. **OpenGL errors**: Shader compilation errors logged
4. **Permission denied**: User prompted, app handles gracefully

## Testing

### Manual Testing Checklist

- [ ] Camera permission granted
- [ ] Camera opens successfully
- [ ] Frames are captured
- [ ] Edge detection works
- [ ] Toggle button switches modes
- [ ] FPS counter updates
- [ ] App handles camera disconnect
- [ ] App handles orientation changes
- [ ] Memory doesn't leak (check with Android Profiler)

### Performance Testing

```bash
# Monitor FPS
adb shell dumpsys gfxinfo com.example.edgedetection

# Check memory
adb shell dumpsys meminfo com.example.edgedetection

# Monitor CPU
adb shell top -n 1 | grep edgedetection
```

## Future Enhancements

1. **Multiple edge detection algorithms**
   - Sobel
   - Laplacian
   - Scharr

2. **Real-time parameter adjustment**
   - Canny thresholds
   - Blur amount
   - Edge thickness

3. **Frame recording**
   - Save processed frames
   - Video recording

4. **Web integration**
   - HTTP server on device
   - WebSocket streaming
   - Remote control

5. **Performance improvements**
   - GPU-accelerated processing
   - Multi-threaded OpenCV
   - Custom OpenGL shaders for edge detection

## Code Organization

```
app/src/main/
├── java/com/example/edgedetection/
│   ├── MainActivity.kt          # Main UI, camera handling
│   ├── NativeProcessor.kt       # JNI wrapper
│   └── EdgeGLRenderer.kt        # OpenGL rendering
├── cpp/
│   └── native-lib.cpp           # JNI bridge
├── jni/
│   ├── edge_detector.h
│   └── edge_detector.cpp        # OpenCV processing
└── gl/
    ├── gl_renderer.h
    └── gl_renderer.cpp          # OpenGL utilities
```

## Dependencies

- **Android SDK**: API 24+ (Android 7.0)
- **NDK**: r21+
- **OpenCV**: 4.5.0+
- **Kotlin**: 1.9.0
- **Gradle**: 8.1.0

## Build Process

1. **Gradle sync**: Downloads dependencies
2. **CMake configuration**: Finds OpenCV, sets up native build
3. **Native compilation**: C++ code compiled to .so libraries
4. **Java/Kotlin compilation**: App code compiled
5. **APK assembly**: Everything packaged into APK
6. **Installation**: APK installed on device

## Debugging

### Native Code
```bash
# View native logs
adb logcat | grep -E "NativeLib|EdgeDetector|GLRenderer"

# Debug with GDB
adb shell gdbserver :5039 /data/app/com.example.edgedetection/lib/arm64/libnative-lib.so
```

### Java/Kotlin
```bash
# View app logs
adb logcat | grep -E "MainActivity|NativeProcessor|EdgeGLRenderer"

# Check for crashes
adb logcat *:E
```

### OpenGL
- Use GPU Debugger in Android Studio
- Check for GL errors in logcat
- Verify shader compilation

